
var PLAY=1;
var END=0;
var gameState=PLAY;
var monkey;
var obstacleGroup,stone;
var bananaGroup, banana;
var ground;


var background


function preload(){
  monkey=loadAnimation ("monkey_1.png", "monkey_2.png", "monkey_3.png","monkey_4.png","monkey_5.png","monkey_6.png","monkey_7.png","monkey_8.png","monkey_9.png" )
 
  obstacleGroup=loadAnimation("stone.png");
  bananaGroup=loadImage("banana.png");
  
  
  
  
  
  
  
  
  
}

function setup() {
  createCanvas(400, 400);
  
  monkey=createSprite(60,335,10,10);
  monkey.addAnimation(monkey);
 monkey.scale=0.5;
  
  ground=createSprite(0,365,800,5);
ground.x = ground.width/2;
  
  score=0;
  score.stroke("white");
score.textSize(20);
score.fill("white");
score.text("Score:" + score, 500, 50)
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
}

function draw() {
  background(220);
  
  text("Score:"+score,200,20);
  
  monkey.collide(ground);
  
  if (keyDown("space")&& monkey.y>=330) {
    monkey.velocityY=-14;        
  
  }
  
  monkey.velocityY=monkey.velocityY+0.8;
  
  
  
  ground.velocityX=-5;
  
  if (ground.x < 0){
      ground.x = ground.width/2;
    }
  

  
if (monkey.isTouching(bananaGroup)) {
  bananaGroup.destroyEach();
    score=score+2;
  }
    
switch(score){
  case 10:monkey.scale=0.12;
    break;
  case 20:monkey.scale=0.14;
    break;
  
    case 40:monkey.scale=0.18;
    break;
    
}
  
  if (monkey.isTouching(obstacleGroup)) {
    gameState=END;
   monkey.scale=0.2
  }
  
  
if (gameState===END) {
    bananaGroup.destroyEach();
    ground.velocityX=0;
    monkey.velocityX=0;
    obstacleGroup.setVelocityXEach(0);
  }
    
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  obstacle();
  banana();
    
  drawSprites();
}

function spawnBanana(){
  
  if (World.frameCount % 150===0) {
    var banana=createSprite();
    banana.setAnimation("Banana");
    banana.scale=0.05;
    banana.y=randomNumber(250,350);
  banana.x=400;
  banana.velocityX=-7;
  banana.lifetime=500;
    banana.setCollider("rectangle", 1,1,1,1,1);
  bananaGroup.add(banana);
}
}
  

function spawnObstacle(){
  if (World.frameCount % 300===0) {
    var obstacle=createSprite();
    obstacle.setAnimation("Stone");
    obstacle.scale=0.2;
    obstacle.y=340;
    obstacle.x=400;
    obstacle.velocityX=-7;
    obstacle.lifetime=500;
    
    obstacleGroup.add(obstacle);
  }
  
  



  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
}